# Anon Bundler v2.2 — Solana Token Launch Bundler

All-in-one Solana token launch bundler with Jito atomic bundle execution,
Pump.fun + Raydium CPMM launches, volume bot, auto-sell, SOL recovery.
Fully local — no third-party API for transaction signing.

## What's new in v2.2

| Area | v2.1 → v2.2 |
|------|-------------|
| Pump.fun | Hand-coded instruction → **official `@pump-fun/pump-sdk`** (always up-to-date with program upgrades incl. volume accumulators, fee config, cashback/mayhem) |
| Jupiter | Dead v6 endpoints → **Price V3 + Swap V1** (`lite-api.jup.ag`) |
| Jito tip | Fixed 950k lamports → **dynamic via `tip_floor` API** (configurable percentile + multiplier, hard cap) |
| Jito engines | Mainnet + NY → **Frankfurt + NY + Global** (lower latency for EU users) |
| TX confirmation | 1.5s polling → **blockhash-expiry based** (`confirmTransaction` with `lastValidBlockHeight`) |
| Bundle buys | Hand-coded discriminators → **official SDK `buyInstructions`** with synthesized `BondingCurve` state |
| Raydium CPMM | Outdated SDK shape → **v0.2.41 `CreateCpmmPoolParam`** (full required fields) |
| Migration | Hand-decoded discriminator → **`OnlinePumpSdk.decodeBondingCurveNullable` + `bc.complete`** |
| Token balance | `getTokenAccountsByOwner` (slow, misses multi-ATA) → **`getAssociatedTokenAddressSync`** (direct ATA) |
| LUT | Created but unused → **removed** (didn't help bundle; LUT needs 1 slot to activate) |
| Funding | Legacy TX → **V0 TX with fresh blockhash per batch** |
| Transaction versions | Mixed Legacy/V0 → **V0 throughout** |

## Quick start

```bash
npm install
cp .env.example .env
# edit .env → set RPC_URL, MASTER_PRIVATE_KEY, WALLET_VAULT_PASSWORD, PINATA_JWT
npm start                 # launch
npm run recover           # reclaim SOL from buyer wallets
```

## Environment variables

| Variable | Required | Default | Note |
|---|---|---|---|
| `RPC_URL` | ✅ | — | HTTPS Solana RPC (Helius / QuickNode / Triton recommended) |
| `MASTER_PRIVATE_KEY` | ✅ | — | Base58 private key |
| `WALLET_VAULT_PASSWORD` | ✅ (non-dry-run) | — | AES-256-GCM vault password |
| `PINATA_JWT` | ✅ (non-dry-run) | — | IPFS metadata upload |
| `DRY_RUN` | no | `false` | Simulate only, no TXs sent |
| `MODE` | no | `pump` | `pump` / `raydium` / `multi` |
| `NUM_WALLETS` | no | `20` | Buyer wallet count |
| `SOL_PER_WALLET` | no | `0.28` | Lamports funded per wallet |
| `BUNDLE_WALLETS_COUNT` | no | `3` | Max 3 (Jito 5-tx limit) |
| `CREATOR_BUY_SOL` | no | `0.5` | SOL for creator's initial buy |
| `BUNDLE_BUY_MIN_SOL` | no | `0.09` | Min per bundle buyer |
| `BUNDLE_BUY_MAX_SOL` | no | `0.48` | Max per bundle buyer |
| `JITO_TIP_PERCENTILE` | no | `75` | Targets `landed_tips_Nth_percentile` |
| `JITO_TIP_MULTIPLIER` | no | `1.5` | Applied to percentile value |
| `JITO_TIP_MAX_LAMPORTS` | no | `5_000_000` | Hard cap on tip bid |
| `JITO_TIP_LAMPORTS` | no | `1_000_000` | Fallback if tip_floor API fails |
| `SLIPPAGE_BPS` | no | `500` | Max 1000 (10%) |
| `AUTO_SELL_PERCENT` | no | `35` | Profit target in % |
| `VOLUME_BOT_ENABLED` | no | `true` | Enable post-launch volume bot |
| `VOLUME_BUYS_PER_MIN` | no | `12` | Capped at 30 |
| `AUTO_MIGRATE` | no | `true` | Monitor bonding curve → migration |
| `JUPITER_API_KEY` | no | — | Optional, unlocks higher rate limits |
| `VANITY_PREFIX` | no | — | Optional wallet prefix |

## Architecture

```
src/
├── index.ts           # Main orchestration + state machine + graceful shutdown
├── config.ts          # Env parsing + validation
├── utils.ts           # Jupiter endpoints, Jito tip_floor, confirmTx, rate limiter
├── wallets.ts         # AES-256-GCM encrypted vault, idempotent generation
├── funding.ts         # V0 batch transfers master → buyers
├── jito.ts            # Dynamic tip, multi-engine bundle send + status poll
├── metadata.ts        # Pinata IPFS upload
├── recover.ts         # SOL reclaim from buyers → master
├── launches/
│   ├── pumpfun.ts     # @pump-fun/pump-sdk — createAndBuy + buyInstructions
│   └── raydium.ts     # @raydium-io/raydium-sdk-v2 — CPMM pool creation
└── postlaunch/
    ├── autoSell.ts    # Jupiter price V3 tracking, profit target + trailing stop
    ├── volumeBot.ts   # Jupiter swap V1 randomized buys/sells
    └── migration.ts   # OnlinePumpSdk bonding curve progress + DexScreener check
```

## Security

- Private keys **never leave the machine**
- Wallet vault AES-256-GCM with PBKDF2 (100k iterations) — password-protected
- Always `DRY_RUN=true` first — review output before spending SOL
- Dedicated master wallet (don't reuse a wallet that holds other funds)
- Slippage hard-capped at 10% — mitigates sandwich attacks
- Graceful `SIGINT`/`SIGTERM` shutdown stops all services cleanly

## Legal

Market-making / wash-trading via volume bot may constitute market manipulation
in your jurisdiction (EU MiCA, US federal securities law). Use at your own risk.

## License

No warranties. Do not use for illegal activities.
