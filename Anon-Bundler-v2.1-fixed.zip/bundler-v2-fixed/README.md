# SOLANA MAX BUNDLER v2.1

All-in-one Solana Token Launch Bundler with Jito Bundles, Pump.fun & Raydium support.

## What's New in v2.1

- **FIX: Jito bundle encoding** — was base64 (rejected by Jito), now correctly uses base58
- **FIX: Pump.fun buy instruction** — now calculates actual token amounts from bonding curve instead of passing 0
- **FIX: Bundle tip trimming** — tip TX no longer gets cut when bundle is at max size
- **FIX: Trailing stop sell** — actually executes sells now (was only setting a flag)
- **FIX: Volume bot sell amounts** — sells based on actual token balance instead of random SOL amounts
- **FIX: Wallet vault** — no more plaintext fallback; encryption required for real launches
- **NEW: Recovery script** — `npm run recover` to reclaim SOL from funded wallets after crashes
- **NEW: Rate limiting** — Jupiter API calls are rate-limited to avoid 429s
- **NEW: Configurable creator buy** — `CREATOR_BUY_SOL` env var (was hardcoded 0.5 SOL)
- **NEW: Bonding curve validation** — discriminator check before reading account data

## Features

- **Pump.fun Launch** — local TX construction (no 3rd-party API), atomic create + multi-buy via Jito Bundle
- **Raydium V2 CPMM** — pool creation with full liquidity control
- **Jito Bundles** — real dual-submission to multiple block engines with tip transactions
- **Volume Bot** — Jupiter-based buy/sell cycles with randomized amounts and timing
- **Auto-Sell** — Jupiter price tracking, profit target sells, trailing stop-loss
- **Auto-Migration Monitor** — onchain bonding curve progress tracking, migration detection
- **Wallet Vault** — AES-256-GCM encrypted wallet persistence (crash recovery)
- **Fund Recovery** — reclaim SOL from buyer wallets if launch fails or after you're done
- **Dry-Run Mode** — simulate the entire flow without sending transactions

## Setup

```bash
git clone <your-repo-url>
cd solana-max-bundler
npm install
cp .env.example .env
# Edit .env with your config
```

## Configuration

See `.env.example` for all options. Key settings:

| Variable | Default | Description |
|---|---|---|
| `MODE` | `pump` | `pump`, `raydium`, or `multi` |
| `NUM_WALLETS` | `20` | Number of buyer wallets (1-300) |
| `SOL_PER_WALLET` | `0.28` | SOL funded to each wallet |
| `BUNDLE_WALLETS_COUNT` | `3` | Buyers in Jito bundle (max 3) |
| `CREATOR_BUY_SOL` | `0.5` | Creator's initial buy amount |
| `SLIPPAGE_BPS` | `500` | Slippage tolerance (50-1000 bps) |
| `DRY_RUN` | `true` | Simulate without sending TXs |
| `WALLET_VAULT_PASSWORD` | — | Encrypt wallet vault (**required** for real launches) |
| `PINATA_JWT` | — | Required for IPFS metadata upload |

## Usage

```bash
# Dry run first (always)
DRY_RUN=true npx ts-node src/index.ts

# Real launch
DRY_RUN=false npx ts-node src/index.ts

# Recover SOL from buyer wallets
npm run recover
```

## Architecture

```
src/
├── config.ts            # Validated config with sane defaults
├── utils.ts             # Retry, backoff, TX confirmation, rate limiting
├── wallets.ts           # Generation + encrypted vault (no plaintext)
├── funding.ts           # Balance-checked batch funding
├── lut.ts               # Address Lookup Table with confirmation
├── metadata.ts          # Real Pinata IPFS upload
├── jito.ts              # Bundle sending (base58) + dual submission + polling
├── index.ts             # State machine orchestrator
├── recover.ts           # Fund recovery script
├── launches/
│   ├── pumpfun.ts       # Local TX with bonding curve math
│   └── raydium.ts       # CPMM pool creation
└── postlaunch/
    ├── migration.ts     # Onchain bonding curve monitor (with validation)
    ├── volumeBot.ts     # Jupiter buy/sell cycles (rate limited)
    └── autoSell.ts      # Price tracking + profit target + trailing stop sells
```

## Security

- Never commit `.env` — use `.env.example` as template
- `WALLET_VAULT_PASSWORD` is **required** for non-dry-run launches
- Always start with `DRY_RUN=true`
- Slippage is capped at 10% (1000 bps) to prevent sandwich attacks
- All TX confirmations are awaited before proceeding
- Graceful shutdown (Ctrl+C) stops all services cleanly
- Jupiter API calls are rate-limited to avoid service bans

## Recovery

If the process crashes after wallet funding, wallets are persisted in `wallets/vault.enc` (encrypted). Run:

```bash
npm run recover
```

This will transfer all SOL from buyer wallets back to the master wallet. Note: tokens must be sold manually or via the volume bot before recovery.
